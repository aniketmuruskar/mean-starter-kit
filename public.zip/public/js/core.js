angular.module('scotchTodo', ['todoController', 'todoService']);
